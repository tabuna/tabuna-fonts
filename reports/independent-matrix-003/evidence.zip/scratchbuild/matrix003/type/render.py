from PIL import Image,ImageDraw,ImageFont,features
from pathlib import Path
import hashlib,json
import freetype,uharfbuzz as hb
font=Path('dist/TabunaSansVariable.ttf')
meta={'sha256':hashlib.sha256(font.read_bytes()).hexdigest(),'shaping':'uharfbuzz; freetype grayscale rasterization','version':'0.0.3','renders':[]}
for w in [100,400,900]:
 im=Image.new('RGB',(1280,930),'white'); d=ImageDraw.Draw(im); y=20
 def line(t,s):
  global y
  face=freetype.Face(str(font));face.set_var_design_coords([w,s]);face.set_pixel_sizes(0,s)
  hf=hb.Font(hb.Face(font.read_bytes()));hf.scale=(s*64,s*64);hf.set_variations({'wght':w,'opsz':s})
  buf=hb.Buffer();buf.add_str(t);buf.guess_segment_properties();hb.shape(hf,buf)
  x=24
  for g,pos in zip(buf.glyph_infos,buf.glyph_positions):
   face.load_glyph(g.codepoint,freetype.FT_LOAD_RENDER);bm=face.glyph.bitmap
   if bm.width and bm.rows:
    mask=Image.frombytes('L',(bm.width,bm.rows),bytes(bm.buffer));im.paste((0,0,0),(round(x+pos.x_offset/64+face.glyph.bitmap_left),round(y+s-face.glyph.bitmap_top-pos.y_offset/64)),mask)
   x+=pos.x_advance/64
  y+=int(s*1.5)
 line(f'Tabuna Sans 0.0.3 — weight {w} — opsz = pixel size',24)
 for title,size,lines in [
 ('UI / 14 px',14,['Настройки аккаунта   Сохранить изменения   Отмена   Поиск…','Account settings   Save changes   Cancel   Search…','Профиль: Илья   Счёт № 103   Цена 1 290 ₽   15:40   09.09.2026']),
 ('Body / 18 px',18,['В тихом дворе шумели листья. Илья открыл окно и прочитал письмо:','«Пожалуйста, проверьте адрес, номер счёта и дату отправления».','The quick brown fox jumps over the lazy dog. Reading a paragraph','requires clear letters, steady spacing, and a comfortable rhythm.']),
 ('Heading / 40 px',40,['Новый взгляд на привычные вещи','A clear view of everyday life']),
 ('Identity / 14, 18, 40 px',14,[])]:
  y+=15;line(title,16)
  for t in lines:line(t,size)
 for size in [14,18,40]:line('I l 1  Il1  Ill  111   O 0  O0  ООО 000   rn m   ш щ и й   е ё э',size)
 p=f'scratchbuild/matrix003/type/weight-{w}.png';im.save(p);meta['renders'].append({'weight':w,'opsz':'matched rendered size: 14,18,40','path':p})
Path('scratchbuild/matrix003/type/render-meta.json').write_text(json.dumps(meta,indent=2))
print(json.dumps(meta,indent=2))
