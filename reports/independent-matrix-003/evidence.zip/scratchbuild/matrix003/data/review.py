import json,hashlib,io
from pathlib import Path
import freetype
import uharfbuzz as hb
from fontTools.ttLib import TTFont
from fontTools.varLib.instancer import instantiateVariableFont
from PIL import Image,ImageFont,ImageDraw
root=Path.cwd(); fp=root/'dist/TabunaSansVariable.ttf'; raw=fp.read_bytes(); font=TTFont(fp)
axes=[{'wght':w,'opsz':o} for w,o in [(100,9),(400,9),(400,14),(500,14),(700,14),(900,9),(100,128),(400,128),(900,128)]]
rows=[]
def shape(text,axis,features):
 f=hb.Font(hb.Face(raw));f.scale=(1000,1000);f.set_variations(axis); b=hb.Buffer();b.add_str(text);b.guess_segment_properties();hb.shape(f,b,features)
 return {'gids':[g.codepoint for g in b.glyph_infos], 'adv':[p.x_advance for p in b.glyph_positions], 'width':sum(p.x_advance for p in b.glyph_positions)}
samples=['00:00:00','11:11:11','88:88:88','12:34:56','09:59:59','10:00:00','$ 1,234.56','€ 9.99','₽ 123 456,78','£ 88.00','¥ 1,000','−123.45','+123.45','123.45','888.88','111.11','1.11','12.34','123.45','1234.56']
for a in axes:
 for mode in ['default','tnum','pnum']:
  for calt in [0,1]:
   feat={'calt':calt};feat.update({mode:1} if mode!='default' else {})
   digit=[shape(d,a,feat)['width'] for d in '0123456789']; ss={s:shape(s,a,feat) for s in samples}
   punct={}
   f=hb.Font(hb.Face(raw));f.scale=(1000,1000);f.set_variations(a)
   for c in '.:,;0128$€₽£¥−+':
    gid=shape(c,a,feat)['gids'][0]; ex=f.get_glyph_extents(gid);punct[c]=dict(zip(['x_bearing','y_bearing','width','height'],ex)) if ex else None
   rows.append({'axes':a,'mode':mode,'calt':calt,'digit_widths':digit,'samples':ss,'extents':punct})
Path('scratchbuild/matrix003/data/metrics.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
# Real instantiated variable font outlines rendered by Pillow/FreeType with RAQM shaping.
W=2100; H=9*190+60; img=Image.new('RGB',(W,H),'#f5f5f2');draw=ImageDraw.Draw(img); label=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',15)
for i,a in enumerate(axes):
 inst=instantiateVariableFont(font,a,inplace=False);out=io.BytesIO();inst.save(out); fpath=Path(f'scratchbuild/matrix003/data/instance-{i}.ttf');fpath.write_bytes(out.getvalue());y=30+i*190
 draw.text((20,y),str(a),font=label,fill='black')
 for j,(sz,feat) in enumerate([(16,['tnum','calt']),(32,['tnum','calt']),(32,['pnum','calt'])]):
  f=ImageFont.truetype(str(fpath),sz); x=230+j*610
  draw.text((x,y),f'{sz}px '+','.join(feat),font=label,fill='#555555')
  for k,s in enumerate(['00:00:00 11:11:11 88:88:88','$1,234.56  €9.99  ₽88.00','123.45  888.88  −111.11','1.11   12.34   1234.56']):
   face=freetype.Face(str(fpath));face.set_pixel_sizes(0,sz); shaped=shape(s,a,{tag:1 for tag in feat});pen=float(x); baseline=y+25+k*35+sz
   for gid,advance in zip(shaped['gids'],shaped['adv']):
    face.load_glyph(gid,freetype.FT_LOAD_RENDER);bm=face.glyph.bitmap
    if bm.width and bm.rows:
     mask=Image.frombytes('L',(bm.width,bm.rows),bytes(bm.buffer));img.paste('#151515',(round(pen)+face.glyph.bitmap_left,baseline-face.glyph.bitmap_top),mask)
    pen+=advance*sz/1000
img.save('scratchbuild/matrix003/data/proof.png')
print(json.dumps({'sha256':hashlib.sha256(raw).hexdigest(),'conditions':len(rows),'tnum_failures':[r for r in rows if r['mode']=='tnum' and len(set(r['digit_widths']))>1],'default_widths':rows[0]['digit_widths'],'pnum_widths':rows[4]['digit_widths'],'calt_changed':sum(rows[i]['samples']!=rows[i+1]['samples'] for i in range(0,len(rows),2))},ensure_ascii=False))
