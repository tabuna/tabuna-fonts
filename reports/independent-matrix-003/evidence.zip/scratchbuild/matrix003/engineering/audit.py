import hashlib,json,itertools,io,math
from pathlib import Path
from fontTools.ttLib import TTFont
from fontTools.pens.boundsPen import BoundsPen
import uharfbuzz as hb
root=Path.cwd(); paths=[root/'dist/TabunaSansVariable.ttf',root/'dist/TabunaSansVariable.woff2']; fonts=[TTFont(p) for p in paths]
faces=[]
for f in fonts:
 f.flavor=None;b=io.BytesIO();f.save(b);faces.append(hb.Face(b.getvalue()))
def shape(face,text,loc,features):
 counts['shapes']+=1
 f=hb.Font(face);f.set_variations(loc); b=hb.Buffer();b.add_str(text);b.guess_segment_properties();hb.shape(f,b,features)
 return [(fonts[0].getGlyphName(i.codepoint),i.cluster,p.x_advance,p.x_offset,p.y_offset) for i,p in zip(b.glyph_infos,b.glyph_positions)]
locations=[dict(wght=w,opsz=o) for w in [100,250,400,650,900] for o in [9,14,32,72,128]]
features=[{}, {'calt':0},{'pnum':1},{'tnum':1},{'pnum':1,'tnum':1},{'tnum':1,'calt':0},{'tnum':[(0,1,1)]},{'tnum':[(2,3,1)]},{'tnum':1,'pnum':[(0,1,1)]}]
corpus=['0123456789','12:34','A:B','a:b','А:Б','а:б','A:1','1:A','1 : 2','1\u00a0:\u00a02','11.11','88.88','1,000.00','−1.25%','12/34','12-34','(12)','1+2=3']
counts=dict(shapes=0,container_equivalence=0,default_pnum_equivalence=0,tabular_digit_equal_width=0,tabular_separator_sets=0,glyph_bounds=0)
failures=[];evidence=[]
for loc in locations:
 for s,fe in itertools.product(corpus,features):
  a=shape(faces[0],s,loc,fe);b=shape(faces[1],s,loc,fe);counts['container_equivalence']+=1
  if a!=b: failures.append(dict(test='container_equivalence',location=loc,text=s,features=fe))
 for s in corpus:
  counts['default_pnum_equivalence']+=1
  if shape(faces[0],s,loc,{})!=shape(faces[0],s,loc,{'pnum':1}):failures.append(dict(test='default_pnum_equivalence',location=loc,text=s))
 ds=shape(faces[0],'0123456789',loc,{'tnum':1});counts['tabular_digit_equal_width']+=1
 if len({x[2] for x in ds})!=1: failures.append(dict(test='tabular_digit_equal_width',location=loc,result=ds))
 for sep in [':','.',',','/','-','+','−','%',' ']:
  cases={a+sep+b:sum(x[2] for x in shape(faces[0],a+sep+b,loc,{'tnum':1})) for a,b in itertools.product('0123456789',repeat=2)};counts['tabular_separator_sets']+=1
  if len(set(cases.values()))!=1: failures.append(dict(test='tabular_separator_total_width',location=loc,separator=sep,min_width=min(cases.values()),max_width=max(cases.values()),examples=list(cases.items())[:10]))
 gs=fonts[0].getGlyphSet(location=loc)
 for n in gs:
  p=BoundsPen(gs);gs[n].draw(p);counts['glyph_bounds']+=1
  if p.bounds and (not all(math.isfinite(x) for x in p.bounds) or p.bounds[0]>p.bounds[2] or p.bounds[1]>p.bounds[3]):failures.append(dict(test='bounds',location=loc,glyph=n,bounds=p.bounds))
for s in ['1:2','A:B','a:b','А:Б','а:б','1 : 2','1.2']:
 for fe in features:evidence.append(dict(text=s,features=fe,result=shape(faces[0],s,dict(wght=400,opsz=14),fe)))
out=dict(role='Independent OpenType engineer (automated technical audit; not a human reader or Apple review)',font_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},independence={'prior_reports_read':False,'other_reviewers_findings_read':False,'fresh_test_script':'scratchbuild/matrix003/engineering/audit.py','font_and_source_modified':False},tests={'counts':counts,'locations':locations,'feature_sets':features,'failures':failures,'evidence':evidence},verdicts={},findings=[],limitations=['HarfBuzz and fontTools only; CoreText, browser engines and real users not evaluated.','Finite axis grid covers bounds and metrics, not outline self-intersections or perceptual quality.','Readability, fatigue and typographic beauty cannot be established by this technical audit.'])
Path('reports/independent-matrix-003/engineering.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
print(json.dumps({'counts':counts,'failure_count':len(failures),'failures':failures[:5]},ensure_ascii=False))
