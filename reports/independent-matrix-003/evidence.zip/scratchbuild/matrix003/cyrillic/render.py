from pathlib import Path
import freetype, uharfbuzz as hb, hashlib,json
from PIL import Image,ImageDraw,ImageFont
p=Path('dist/TabunaSansVariable.ttf'); data=p.read_bytes();face=freetype.Face(str(p));hf=hb.Face(data)
out=Path('scratchbuild/matrix003/cyrillic'); meta=[]
def line(img,text,x,y,size,weight,opsz):
 face.set_char_size(size*64);face.set_var_design_coords([weight,opsz]);font=hb.Font(hf);font.scale=(size*64,size*64);font.set_variations({'wght':weight,'opsz':opsz});hb.ot_font_set_funcs(font);buf=hb.Buffer();buf.add_str(text);buf.guess_segment_properties();hb.shape(font,buf)
 for gi,gp in zip(buf.glyph_infos,buf.glyph_positions):
  face.load_glyph(gi.codepoint,freetype.FT_LOAD_RENDER);g=face.glyph;b=g.bitmap
  if b.width and b.rows:
   mask=Image.frombytes('L',(b.width,b.rows),bytes(b.buffer));img.paste((20,20,20),(round(x+gp.x_offset/64)+g.bitmap_left,round(y-gp.y_offset/64)-g.bitmap_top),mask)
  x+=gp.x_advance/64
 meta.append({'text':text,'px':size,'opsz':opsz,'wght':weight,'missing_glyphs':sum(g.codepoint==0 for g in buf.glyph_infos)})
for weight in [100,400,900]:
 im=Image.new('RGB',(1500,1050),'white');d=ImageDraw.Draw(im);d.text((30,15),f'CYRILLIC independent / wght {weight} / px = opsz',fill='black')
 line(im,'Д Л д л б в ж к я Ё й',30,140,96,weight,96)
 line(im,'ДЛдлбвжкяЁй • Длительный дождь',30,225,48,weight,48)
 line(im,'Ёлка, йод и добрая воля',30,298,36,weight,36)
 line(im,'Настройки   Добавить   Удалить   Сохранить',30,354,20,weight,20)
 line(im,'Личный кабинет   Доступ   Файлы   Войти',30,393,16,weight,16)
 line(im,'Подключение   Выключить   Выберите файл',30,430,14,weight,14)
 line(im,'Данные обновлены · Сегодня, 12:45 · Ещё',30,465,12,weight,12)
 texts=['В дождливый день Людмила долго ждала у двери.','Ёлки вдоль бульвара качались, а в окнах зажигался свет.','Большой город жил обычной жизнью: люди шли домой,','дети бежали к школе, и каждый думал о чём-то своём.']
 for i,t in enumerate(texts): line(im,t,30,530+i*25,18,weight,18)
 for i,t in enumerate(texts): line(im,t,30,675+i*20,14,weight,14)
 line(im,'ДЛ дл Лл Дд бв вб жк кж яа ЁЕ йи',30,825,32,weight,32)
 line(im,'ддд ллл ббб ввв жжж ккк яяя ЁЁЁ ййй',30,895,40,weight,40)
 line(im,'День и ночь — 1 234 ₽; «Добро пожаловать!»',30,975,24,weight,24)
 im.save(out/f'ru-{weight}.png')
(out/'evidence.json').write_text(json.dumps({'font_sha256':hashlib.sha256(data).hexdigest(),'tests':meta},ensure_ascii=False,indent=2))
